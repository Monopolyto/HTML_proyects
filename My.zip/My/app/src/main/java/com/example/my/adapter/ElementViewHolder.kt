package com.example.my.adapter

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.my.Element
import com.example.my.R

class ElementViewHolder(view:View):RecyclerView.ViewHolder(view) {

    val elemento=view.findViewById<TextView>(R.id.tvElement)
    val nombre=view.findViewById<TextView>(R.id.tvNombre)
    val origen=view.findViewById<TextView>(R.id.tvOrigen)
    val foto=view.findViewById<ImageView>(R.id.ivElement)

    fun render(elementModel:Element){
        elemento.text=elementModel.element
        nombre.text=elementModel.nombre
        origen.text=elementModel.origen
        Glide.with(foto.context).load(elementModel.foto).into(foto)
    }
}