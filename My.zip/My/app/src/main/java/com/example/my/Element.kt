package com.example.my

data class Element (
    val element:String,
    val nombre:String,
    val origen:String,
    val foto:String
)