package com.example.my

class Provider {
    companion object{
        val elementolist = listOf<Element>(
            Element(
                "Metodo",
                "Prueba y Error",
                "Robo de contraseña",
                "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/493486b7-875a-413a-8d46-059e8eb70c13/dgae96m-881f0aa3-1a9b-4d6f-b0d4-b5efc43d928d.png/v1/fit/w_500,h_500/a1_by_sakayaki_dgae96m-375w-2x.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTAwIiwicGF0aCI6IlwvZlwvNDkzNDg2YjctODc1YS00MTNhLThkNDYtMDU5ZThlYjcwYzEzXC9kZ2FlOTZtLTg4MWYwYWEzLTFhOWItNGQ2Zi1iMGQ0LWI1ZWZjNDNkOTI4ZC5wbmciLCJ3aWR0aCI6Ijw9NTAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.NIkou8upY8JpoNQ5z2v0VhlNj4buQOAmhdm6oFG3OVw"
            ),
            Element(
                "Metodo",
                "Ataque por Diccionario",
                "Robo de contraseña",
                "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/493486b7-875a-413a-8d46-059e8eb70c13/dgae96x-ff7a9f63-7b6c-4299-b08b-edcac0a43691.png/v1/fit/w_500,h_500/a2_by_sakayaki_dgae96x-375w-2x.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTAwIiwicGF0aCI6IlwvZlwvNDkzNDg2YjctODc1YS00MTNhLThkNDYtMDU5ZThlYjcwYzEzXC9kZ2FlOTZ4LWZmN2E5ZjYzLTdiNmMtNDI5OS1iMDhiLWVkY2FjMGE0MzY5MS5wbmciLCJ3aWR0aCI6Ijw9NTAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.luidpb5sLruu7Dn_3pUcfFMCcr-_RGxK1xYhd_az8g8"
            ),
            Element(
                "Metodo",
                "Phishing",
                "Recopilar datos personales",
                "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/493486b7-875a-413a-8d46-059e8eb70c13/dgae973-c92ff29e-fdf2-48bf-9260-a4201232bbb9.png/v1/fit/w_500,h_500/a3_by_sakayaki_dgae973-375w-2x.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTAwIiwicGF0aCI6IlwvZlwvNDkzNDg2YjctODc1YS00MTNhLThkNDYtMDU5ZThlYjcwYzEzXC9kZ2FlOTczLWM5MmZmMjllLWZkZjItNDhiZi05MjYwLWE0MjAxMjMyYmJiOS5wbmciLCJ3aWR0aCI6Ijw9NTAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.5e-A1mk5MwjrSVRe7_g1JSkb2Vbc9RNRmn7rNLt5yTs"
            ),
            Element(
                "Programa",
                "Keylogger",
                "Registrar pulsaciones",
                "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/493486b7-875a-413a-8d46-059e8eb70c13/dgae97c-e0777e5a-1cfb-49bc-b88e-c07a47c6a3c2.png/v1/fit/w_500,h_500/a4_by_sakayaki_dgae97c-375w-2x.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTAwIiwicGF0aCI6IlwvZlwvNDkzNDg2YjctODc1YS00MTNhLThkNDYtMDU5ZThlYjcwYzEzXC9kZ2FlOTdjLWUwNzc3ZTVhLTFjZmItNDliYy1iODhlLWMwN2E0N2M2YTNjMi5wbmciLCJ3aWR0aCI6Ijw9NTAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.9lGL8Y1AXcE1Bhbima9e7WcGBevrr9L3uyqoow9AwIM"
            ),
            Element(
                "Programa",
                "Malware",
                "Infectar sistema operativo",
                "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/493486b7-875a-413a-8d46-059e8eb70c13/dgae97j-9076a5b1-3b03-4f73-a55a-a991f1f76a23.png/v1/fit/w_500,h_500/a5_by_sakayaki_dgae97j-375w-2x.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTAwIiwicGF0aCI6IlwvZlwvNDkzNDg2YjctODc1YS00MTNhLThkNDYtMDU5ZThlYjcwYzEzXC9kZ2FlOTdqLTkwNzZhNWIxLTNiMDMtNGY3My1hNTVhLWE5OTFmMWY3NmEyMy5wbmciLCJ3aWR0aCI6Ijw9NTAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.vKrgjs1OQz1IAhXt7sjDLBCMlFxfie8o9Rd49uk8nLs"
            ),
            Element(
                "Programa",
                "Spyware",
                "Recopilar datos personales",
                "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/493486b7-875a-413a-8d46-059e8eb70c13/dgae981-b7ad09b9-88d1-4c1a-b985-5dcf2118236f.png/v1/fit/w_500,h_500/a7_by_sakayaki_dgae981-375w-2x.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTAwIiwicGF0aCI6IlwvZlwvNDkzNDg2YjctODc1YS00MTNhLThkNDYtMDU5ZThlYjcwYzEzXC9kZ2FlOTgxLWI3YWQwOWI5LTg4ZDEtNGMxYS1iOTg1LTVkY2YyMTE4MjM2Zi5wbmciLCJ3aWR0aCI6Ijw9NTAwIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmltYWdlLm9wZXJhdGlvbnMiXX0.924QO4wqlHQZN-Uxv7VblbowRo83carIEoxBXzfyDDc"
            )

        )
    }
}