package com.example.my

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Spinner
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.my.adapter.ElementAdapter

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val spinner = findViewById<Spinner>(R.id.spinner)


        spinner.onItemSelectedListener = object :AdapterView.OnItemSelectedListener{
            override fun onItemSelected(adapterView: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedItem = adapterView?.getItemAtPosition(position).toString()
                if (selectedItem == "Metodo") {
                    metaDos()
                    Toast.makeText(
                        this@MainActivity,
                        "Has seleccionado: ${adapterView?.getItemAtPosition(position).toString()}",Toast.LENGTH_LONG).show()
                }
                if (selectedItem == "Programa") {
                    metaUno()
                    Toast.makeText(
                        this@MainActivity,
                        "Has seleccionado: ${adapterView?.getItemAtPosition(position).toString()}",Toast.LENGTH_LONG).show()
                }

            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
            }

        }

        initRecycleView()
    }

    private fun metaUno(){
        val intent = Intent(this,Programas1::class.java)
        startActivity(intent)
    }

    private fun metaDos(){
        val intent = Intent(this,Metodos1::class.java)
        startActivity(intent)
    }

    private fun initRecycleView(){
        val recyclerView=findViewById<RecyclerView>(R.id.recycler)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = ElementAdapter(Provider.elementolist)
    }

}